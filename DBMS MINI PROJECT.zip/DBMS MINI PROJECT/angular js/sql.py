from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'violin123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:violin123@localhost/proctorbook'

db = SQLAlchemy(app)
branch=1
sem=5
class Subject(db.Model):
    subject_id = db.Column(db.String(11), nullable=False, primary_key=True)
    subject_name = db.Column(db.String(30), nullable=False)
    branch_id = db.Column(db.Integer, nullable=False)
    sub_semid = db.Column(db.Integer, nullable=False)

with app.app_context():
    subject_ids = Subject.query.filter(
        Subject.branch_id == branch,
        Subject.sub_semid == sem
    ).all()
    print('jai nandu baba')
    print(subject_ids)




<link rel="stylesheet" href="{{ url_for('static', filename='main.css') }}">